export class Reservation {

    constructor(
        public firstName:string,
        public lastName:string,
        public middleName:string,
        public email:string,
        public phone:string,
        public cardNumber:string,
        public expirationDate:string,
        public securityCode:string,
        public flightId:string) {  }
  
  }
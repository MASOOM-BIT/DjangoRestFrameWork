export class Criteria {

    constructor(
        public departureCity:string,
        public arrivalCity:string,
        public dateOfDeparture:string) {  }
  
  }